# 星途AI — 原型文件说明

> 本目录包含 9 个独立 HTML 原型文件，用于前端开发参考。每个文件可直接在浏览器中打开预览。

## 文件索引

| 文件 | 页面 | 说明 |
|------|------|------|
| `00-welcome.html` | 欢迎页 | App 启动落地页，星球+星星角色动画、品牌展示、登录/体验双入口 |
| `01-login.html` | 登录页 | 手机号+验证码登录，含用户协议/隐私政策弹窗 |
| `02-chat.html` | 对话页（核心） | AI 对话主界面，消息气泡、训练卡片、趋势图、表格、图片消息、流式光标、输入栏、孩子切换 |
| `03-quick-menu.html` | 快捷菜单 | 左上角宫格入口面板，6 个功能入口 + 数据摘要卡片 |
| `04-settings.html` | 设置页 | 右上角齿轮进入，个人信息、通知、隐私、关于等分组设置项 |
| `05-create-child.html` | 创建孩子档案 | 3 步向导：基本信息 → 医疗信息 + 六大领域评估 → 完成确认 |
| `06-card-fullscreen.html` | 卡片全屏态 | 对话中缩略卡片点击展开为底部 Sheet，含 3 个 Tab：训练趋势、能力画像（雷达图）、评估报告 |
| `07-assessment.html` | M-CHAT 筛查 | 对话式 M-CHAT-R/F 自闭症风险筛查，20 题问答 + 结果卡片 |
| `08-home-guide.html` | 首页引导 | 登录后首页，问候区 + 数据摘要 + AI引导卡片 + 今日待办 + 快捷入口 |

## 如何使用

1. 直接双击 `.html` 文件在浏览器中打开
2. 推荐使用 Chrome / Safari，窗口宽度 ≥ 500px
3. 每个文件都是独立的，无外部依赖，无需启动服务器

## 设计系统

所有原型统一使用以下设计规范，开发时以此为准：

```css
:root {
  --primary: #7C4DFF;          /* 主色紫 */
  --primary-light: #B388FF;    /* 浅紫 */
  --bg: #F5F3FF;               /* 页面背景 */
  --glass-white: rgba(255,255,255,0.88);  /* 毛玻璃白 */
  --glass-card: rgba(255,255,255,0.85);   /* 毛玻璃卡片 */
  --text: #1A1A2E;             /* 主文字 */
  --text-secondary: #6B7280;   /* 次要文字 */
  --radius: 16px;              /* 圆角 */
}
```

### 关键视觉元素

| 元素 | 规范 |
|------|------|
| 字体栈 | `-apple-system, BlinkMacSystemFont, 'SF Pro Display', 'PingFang SC', 'Helvetica Neue', sans-serif` |
| phone-frame | 420×900px，展示用尺寸。实际开发基准为 iPhone 14 逻辑分辨率 390×844 |
| 毛玻璃效果 | `backdrop-filter: blur(20px); -webkit-backdrop-filter: blur(20px)` |
| 渐变按钮 | `background: linear-gradient(135deg, #7C4DFF, #E040FB)` |
| 分割线 | `1px solid rgba(124,77,255,0.08)` |
| 阴影 | `box-shadow: 0 4px 20px rgba(124,77,255,0.06)` |
| 角色配色 | 家长紫 `#7C4DFF`、医生蓝 `#2196F3`、老师翡翠绿 `#00B894`、机构石墨灰 `#2C3E50` |

### 六大发展领域（05/06 文件中使用）

| 领域 | 英文 Key | 图标 |
|------|----------|------|
| 语言沟通 | language_communication | 🗣️ |
| 社交互动 | social_interaction | 🤝 |
| 认知学习 | cognition_learning | 🧠 |
| 感觉运动 | sensory_motor | 🏃 |
| 情绪行为 | emotion_behavior | 💛 |
| 生活适应 | daily_living | 🍽️ |

每个领域 Lv1-Lv6 共 6 个等级，详见 `docs/07-六大领域定义.md`。

## 页面流转关系

```
00-welcome（启动落地页）→ 01-login → 05-create-child（首次登录）→ 08-home-guide（首页引导）→ 02-chat（核心页面）
                                                                                                    ├── 03-quick-menu（左上角菜单）
                                                                                                    ├── 04-settings（右上角齿轮）
                                                                                                    ├── 06-card-fullscreen（卡片点击展开）
                                                                                                    └── 07-assessment（筛查入口触发）
```

## 开发注意事项

- 原型中的 phone-frame 420×900 仅用于浏览器展示，实际 Expo 开发不需要这个容器
- 原型中的交互（点击、动画、切换）展示的是目标效果，具体实现用 React Native 组件
- CSS 变量值是权威参考，开发时映射到 `theme/` 目录下的主题配置
- 原型中使用 emoji 作为头像占位，实际产品使用 Rive/Lottie 3D 星星角色
- 图表（折线图、雷达图）原型用 SVG 静态展示，实际开发推荐 `react-native-svg` + `d3-shape`
